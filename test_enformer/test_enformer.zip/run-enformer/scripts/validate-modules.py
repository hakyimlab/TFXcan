import os, re
import importlib.util

pkg = '../metadata/packages.txt'

# For illustrative purposes.
package_name = 'pandas'

def confirm_module(pname, p):
    boo = importlib.util.find_spec(pname)
    if boo is None:
        print(f'[ERROR] {pname} is not installed. Run "pip install {p}"')
        return(1)
    else:
        print(f'[SUCCESS] {pname} is installed')
        return(0)

with open('../metadata/package_versions.txt', 'r') as pw:
    all_pkgs = pw.readlines()
    for p in all_pkgs:
        p = p.strip()

        pname = p.split('==')[0]
        confirm_module(pname, p)

# zip -r test_enformer.zip ./test_enformer -x "*/\get_versions.py" -x "*/\packages.txt"