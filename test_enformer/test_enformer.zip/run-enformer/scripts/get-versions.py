

import os, re
import importlib.metadata

pkg = '../metadata/packages.txt'

pkg_ver = []
with open(pkg, 'r') as pk:
    with open('../metadata/package_versions.txt', 'w') as pw:
        all_pkgs = pk.readlines()
        for p in all_pkgs:
            p = p.strip()

            try:
                p_version = importlib.metadata.version(p)
                print(f'{p}=={p_version}')
                pkg_ver.append(f'{p}=={p_version}')
            except:
                print(p)
                pkg_ver.append(p)
        pw.writelines('\n'.join(pkg_ver))


# >>> import importlib.metadata
# >>> import.metadata.version('matplotlib')
#   File "<stdin>", line 1
#     import.metadata.version('matplotlib')
#           ^
# SyntaxError: invalid syntax
# >>> importlib.metadata.version('matplotlib')