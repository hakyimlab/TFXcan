
# === This script contains all codes to test if tensorflow and ENFORMER are working accurately 
# === Modified by Temi from Deepmind people
# === DATE: Thursday Oct 20 2022


import os, re, sys, json

def predict_query(query, output_dir, model, fasta_extractor, SEQUENCE_LENGTH = 393216):
    '''
    Parameters :
    query : a list [chr, start, end, unique_id]
    model : the path to the ENFORMER Model
    fasta_extractor : fasta extractor

    Returns :
    A list of predictions; the first element is the predictions around the TSS for each gene. The second is the prediction across CAGE tracks
    '''
    query_chr = query[0]
    query_start, query_end = int(query[1]), int(query[2])
    query_id = query[3]

    target_interval = kipoiseq.Interval(query_chr, query_start, query_end) # creates an interval to select the right sequences

    target_fa = fasta_extractor.extract(target_interval.resize(SEQUENCE_LENGTH))  # extracts the fasta sequences, and resizes such that it is compatible with the sequence_length

    obj_to_save = model.predict_on_batch(one_hot_encode(target_fa)[np.newaxis])['human'][0]

    h5_save = str(f'{output_dir}/{query_id}_predictions.h5')
    with h5py.File(h5_save, 'w') as hf:
        hf.create_dataset(query_chr, data=obj_to_save)


def main():

    # get the path of the script as well as metadata         
    whereis_script = os.path.dirname(sys.argv[0])  
    script_path = os.path.abspath(whereis_script) 

    # read the metadata file
    f = open(f'{script_path}/../metadata/enformer_parameters.json')
    metadata = json.load(f)

    intervals_list = metadata['interval_list_file']
    model_path = metadata['model_path']
    fasta_file = metadata['hg19_fasta_file']
    output_dir = metadata['output_dir']

    usage_codes = f'{script_path}/enformer-usage-codes.py'

    # import the enformer-usage_codes.py file
    exec(open(usage_codes).read(), globals(), globals())

    enf_model = Enformer(model_path)
    sequence_extractor = FastaStringExtractor(fasta_file)

    with open(intervals_list, 'r') as il:
        all_intervals = il.readlines()

        for line in all_intervals:
            query = line.strip().split(' ') 

            print(f"\n[PREDICTING] {query[3]}\n")

            predict_query(query=query, output_dir=output_dir, model=enf_model, fasta_extractor=sequence_extractor)
            
            print(f"[DONE]\n")


if __name__ == '__main__':
    main()
    
    
