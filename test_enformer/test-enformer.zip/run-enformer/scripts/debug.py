import os, sys, json    

# get the path of the script            
whereis_script = os.path.dirname(sys.argv[0])  
script_path = os.path.abspath(whereis_script) 

# read the metadata file
f = open(f'{script_path}/../metadata/enformer_parameters.json')
metadata = json.load(f)

intervals_list = metadata['interval_list_file']
model_path = metadata['model_path']
fasta_path = metadata['hg19_fasta_file']
output_dir = metadata['output_dir']

with open(intervals_list, 'r') as il:
    all_intervals = il.readlines()

    for line in all_intervals:
        query = line.strip().split(' ') 
        print(query)

    